const express = require('express');
const db = require('./db');
const { authRequired } = require('../middleware/auth');
const { agentPayout } = require('./commission');
const { getOtpExpirySec, getRecentOtpHours } = require('./settings');

const router = express.Router();

// GET /api/numbers/config — shared live-number timing config
router.get('/config', authRequired, (req, res) => {
  res.json({
    otp_expiry_sec: getOtpExpirySec(),
    server_now: Math.floor(Date.now() / 1000),
  });
});

// GET /api/numbers/my — agent's "live" working list
router.get('/my', authRequired, (req, res) => {
  const recentHours = getRecentOtpHours();
  const cutoff = Math.floor(Date.now() / 1000) - recentHours * 3600;
  const numbers = db.prepare(`
    SELECT a.id, a.phone_number, a.operator, a.country_code, a.otp, a.status,
           a.allocated_at, a.otp_received_at, a.no_expire, a.source,
           s.slug AS service_slug, s.name AS service_name, s.icon AS service_icon, s.color AS service_color
    FROM allocations a
    LEFT JOIN services s ON s.id = a.service_id
    WHERE a.user_id = ?
      AND (
        a.status = 'active'
        OR (a.status = 'received' AND a.otp_received_at >= ?)
      )
    ORDER BY a.allocated_at DESC LIMIT 200
  `).all(req.user.id, cutoff);
  res.json({
    numbers,
    recent_window_hours: recentHours,
    otp_expiry_sec: getOtpExpirySec(),
    server_now: Math.floor(Date.now() / 1000),
    is_vip: !!req.user.is_vip,
  });
});

// GET /api/numbers/history — paginated OTP history (CDR)
router.get('/history', authRequired, (req, res) => {
  const page = Math.max(1, +(req.query.page) || 1);
  const pageSize = Math.max(1, Math.min(200, +(req.query.page_size) || 50));
  const q = (req.query.q || '').toString().trim();
  const isCsv = (req.query.format || '').toString().toLowerCase() === 'csv';
  const wantFacets = (req.query.facets || '').toString() === '1';

  const parseTs = (v, endOfDay = false) => {
    if (v === undefined || v === null || v === '') return null;
    const s = String(v).trim();
    if (/^\d+$/.test(s)) return +s;
    const d = new Date(s);
    if (isNaN(d.getTime())) return null;
    if (endOfDay && /^\d{4}-\d{2}-\d{2}$/.test(s)) d.setHours(23, 59, 59, 999);
    return Math.floor(d.getTime() / 1000);
  };
  const fromTs = parseTs(req.query.from, false);
  const toTs = parseTs(req.query.to, true);

  // Status filter — CDR only ever stores `billed` (arrived) and `refunded`.
  // Accept comma-separated list. Default = arrived only (= billed).
  const ALLOWED_STATUSES = new Set(['billed', 'refunded']);
  const rawStatus = (req.query.status || '').toString().trim();
  const statusList = rawStatus
    ? rawStatus.split(',').map(s => s.trim().toLowerCase()).filter(s => ALLOWED_STATUSES.has(s))
    : ['billed'];
  const effectiveStatuses = statusList.length ? statusList : ['billed'];

  // Country / operator multi-select filters (comma-separated).
  const splitCsv = (v) => (v || '').toString().split(',').map(s => s.trim()).filter(Boolean);
  const countries = splitCsv(req.query.countries).map(s => s.toUpperCase());
  const operators = splitCsv(req.query.operators);

  const where = ["user_id = ?"];
  const params = [req.user.id];
  // Status (always at least 'billed' by default — preserves prior behaviour).
  where.push(`status IN (${effectiveStatuses.map(() => '?').join(',')})`);
  params.push(...effectiveStatuses);
  // Defense-in-depth: never show fakes in agent-facing CDR even if mis-attributed.
  where.push("(note IS NULL OR note != 'fake:broadcast')");
  if (q) {
    where.push("(phone_number LIKE ? OR otp_code LIKE ? OR operator LIKE ?)");
    params.push(`%${q}%`, `%${q}%`, `%${q}%`);
  }
  if (countries.length) {
    where.push(`UPPER(COALESCE(country_code,'')) IN (${countries.map(() => '?').join(',')})`);
    params.push(...countries);
  }
  if (operators.length) {
    where.push(`COALESCE(operator,'') IN (${operators.map(() => '?').join(',')})`);
    params.push(...operators);
  }
  if (fromTs !== null) { where.push("created_at >= ?"); params.push(fromTs); }
  if (toTs !== null) { where.push("created_at <= ?"); params.push(toTs); }
  const whereSql = where.join(' AND ');

  if (isCsv) {
    const rows = db.prepare(`
      SELECT phone_number, otp_code FROM cdr WHERE ${whereSql}
      ORDER BY created_at DESC LIMIT 50000
    `).all(...params);
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="otp-history-${new Date().toISOString().slice(0,10)}.txt"`);
    for (const r of rows) {
      if (!r.phone_number) continue;
      res.write(r.otp_code ? `${r.phone_number}|${r.otp_code}\n` : `${r.phone_number}\n`);
    }
    return res.end();
  }

  const total = db.prepare(`SELECT COUNT(*) c FROM cdr WHERE ${whereSql}`).get(...params).c;
  // Note: `where` uses unprefixed cols; works fine with table alias because
  // SQLite resolves unambiguous column names against the FROM table.
  const rows = db.prepare(`
    SELECT cdr.id, cdr.allocation_id, cdr.country_code, cdr.operator, cdr.phone_number,
           cdr.otp_code, cdr.cli, cdr.status, cdr.price_bdt, cdr.created_at,
           s.slug AS service_slug, s.name AS service_name, s.icon AS service_icon, s.color AS service_color
    FROM cdr LEFT JOIN services s ON s.id = cdr.service_id
    WHERE ${whereSql}
    ORDER BY cdr.created_at DESC
    LIMIT ? OFFSET ?
  `).all(...params, pageSize, (page - 1) * pageSize);

  const agg = db.prepare(`
    SELECT COUNT(*) c, COALESCE(SUM(price_bdt),0) s
    FROM cdr WHERE ${whereSql}
  `).get(...params);

  // Facets — list every country/operator the agent has *ever* delivered for,
  // independent of the current filter, so the dropdowns stay stable.
  let facets;
  if (wantFacets) {
    const facetWhere = "user_id = ? AND status IN ('billed','refunded') AND (note IS NULL OR note != 'fake:broadcast')";
    const facetCountries = db.prepare(`
      SELECT UPPER(COALESCE(country_code,'')) AS code, COUNT(*) AS c
      FROM cdr WHERE ${facetWhere} AND COALESCE(country_code,'') != ''
      GROUP BY code ORDER BY c DESC, code ASC LIMIT 200
    `).all(req.user.id).map(r => ({ value: r.code, count: r.c }));
    const facetOperators = db.prepare(`
      SELECT COALESCE(operator,'') AS op, COUNT(*) AS c
      FROM cdr WHERE ${facetWhere} AND COALESCE(operator,'') != ''
      GROUP BY op ORDER BY c DESC, op ASC LIMIT 200
    `).all(req.user.id).map(r => ({ value: r.op, count: r.c }));
    facets = { countries: facetCountries, operators: facetOperators };
  }

  res.json({
    rows, page, page_size: pageSize, total,
    total_pages: Math.max(1, Math.ceil(total / pageSize)),
    summary: { count: agg.c, earnings_bdt: +(+agg.s).toFixed(2) },
    ...(facets ? { facets } : {}),
  });
});

// POST /api/numbers/release/:id — agent releases an active allocation
router.post('/release/:id', authRequired, (req, res) => {
  const id = +req.params.id;
  const a = db.prepare("SELECT * FROM allocations WHERE id = ? AND user_id = ?").get(id, req.user.id);
  if (!a) return res.status(404).json({ error: 'Not found' });
  db.prepare("UPDATE allocations SET status = 'released' WHERE id = ?").run(id);
  res.json({ ok: true });
});

// GET /api/numbers/:id/thread — full SMS thread for one allocation
// Returns every CDR row matching this allocation_id PLUS any other CDR row
// for the SAME phone_number from this user within the last 24h (resends,
// follow-up codes). Includes raw `sms_text` so the agent sees the full SMS.
router.get('/:id/thread', authRequired, (req, res) => {
  const id = +req.params.id;
  const a = db.prepare(`
    SELECT a.id, a.phone_number, a.provider, a.country_code, a.operator,
           a.status, a.allocated_at, a.otp_received_at, a.user_id,
           s.slug AS service_slug, s.name AS service_name, s.icon AS service_icon, s.color AS service_color
    FROM allocations a
    LEFT JOIN services s ON s.id = a.service_id
    WHERE a.id = ? AND a.user_id = ?
  `).get(id, req.user.id);
  if (!a) return res.status(404).json({ error: 'Not found' });

  // Cutoff: 24h before allocation start, captures any straggler resends.
  const since = (a.allocated_at || Math.floor(Date.now()/1000)) - 3600;
  const messages = db.prepare(`
    SELECT id, otp_code, cli, sms_text, created_at, allocation_id, price_bdt, status
    FROM cdr
    WHERE user_id = ? AND phone_number = ? AND created_at >= ?
      AND (note IS NULL OR note != 'fake:broadcast')
    ORDER BY created_at ASC
  `).all(req.user.id, a.phone_number, since);

  res.json({ allocation: a, messages, server_now: Math.floor(Date.now() / 1000) });
});

// =============================================================
// POST /api/numbers/get — allocate one or more numbers from a range pool
// Body: { range_id?, provider?, country_code?, range?, count? }
// Honours per-agent per_request_limit (admin-controlled, 1..500).
// =============================================================
router.post('/get', authRequired, (req, res) => {
  const u = req.user;
  return allocateNumbers(req, res, { source: 'web' });
});

// Reusable allocator — used by both web (/api/numbers/get) and the VIP
// /api/v1/numbers/get endpoint.
function allocateNumbers(req, res, { source = 'web' } = {}) {
  const u = req.user;
  if (u.status && u.status !== 'active') {
    return res.status(403).json({ error: 'Account is not active' });
  }

  const body = req.body || {};
  let rangeRow = null;
  if (body.range_id) {
    rangeRow = db.prepare('SELECT * FROM provider_ranges WHERE id = ? AND enabled = 1').get(+body.range_id);
  } else if (body.provider && body.country_code && body.range) {
    rangeRow = db.prepare(
      'SELECT * FROM provider_ranges WHERE provider = ? AND country_code = ? AND range_label = ? AND enabled = 1'
    ).get(body.provider, String(body.country_code).toUpperCase(), body.range);
  }
  if (!rangeRow) return res.status(404).json({ error: 'Range not found or disabled' });

  // Per-agent caps (admin-controlled): per-request limit + daily limit.
  const fresh = db.prepare('SELECT daily_limit, per_request_limit, status, rl_per_min, rl_concurrent FROM users WHERE id = ?').get(u.id);
  if (!fresh || fresh.status !== 'active') return res.status(403).json({ error: 'Account is not active' });
  const getSettingRaw = (k) => db.prepare("SELECT value FROM settings WHERE key=?").get(k)?.value;
  const dailyEnforced = (getSettingRaw('daily_limit_enabled') ?? 'true') !== 'false';
  const globalDefault = Math.max(1, +(getSettingRaw('daily_limit_default') || 500));
  const dailyCap = Math.max(1, +fresh.daily_limit || globalDefault);

  // Daily limit = NUMBERS allocated today (whether or not an OTP arrives).
  const todayStart = Math.floor(new Date().setHours(0, 0, 0, 0) / 1000);
  const usedToday = db.prepare(
    "SELECT COUNT(*) c FROM allocations WHERE user_id=? AND allocated_at >= ?"
  ).get(u.id, todayStart).c;
  const remainingToday = dailyEnforced ? Math.max(0, dailyCap - usedToday) : Number.MAX_SAFE_INTEGER;
  if (dailyEnforced && remainingToday <= 0) {
    return res.status(429).json({
      error: `Daily number limit reached (${dailyCap}/day). Try again tomorrow.`,
      code: 'daily_limit', daily_cap: dailyCap, used_today: usedToday,
    });
  }

  // Per-request cap: per-agent override, else global default (5).
  const perReqDefault = Math.max(1, +(getSettingRaw('per_request_max_default') || 5));
  // VIP agents bypass the standard per-request cap and use their VIP cap
  // (default 50). Admin can raise via users.vip_per_request_limit.
  const isVip = !!u.is_vip;
  const vipCap = Math.max(1, +u.vip_per_request_limit || 50);
  const perReqCap = isVip ? vipCap : Math.max(1, +fresh.per_request_limit || perReqDefault);
  let count = Math.max(1, Math.min(remainingToday, perReqCap, +body.count || 1));
  if ((+body.count || 1) > perReqCap) {
    return res.status(429).json({
      error: `Per-request limit is ${perReqCap}. Ask admin to raise it.`,
      code: 'per_request_limit', per_request_cap: perReqCap,
    });
  }

  // ── Rate-limit gate: per-minute requests + concurrent active allocations ──
  const getSetting = (k, fb) => +(getSettingRaw(k) ?? fb) || +fb;
  const perMin     = +fresh.rl_per_min    > 0 ? +fresh.rl_per_min    : getSetting('rl_per_min_default', 500);
  const concurrent = +fresh.rl_concurrent > 0 ? +fresh.rl_concurrent : getSetting('rl_concurrent_default', 500);
  const since = Math.floor(Date.now() / 1000) - 60;
  const recent = db.prepare(
    "SELECT COUNT(*) c FROM allocations WHERE user_id=? AND allocated_at >= ?"
  ).get(u.id, since).c;
  const active = db.prepare(
    "SELECT COUNT(*) c FROM allocations WHERE user_id=? AND status='active'"
  ).get(u.id).c;
  if (recent + count > perMin) {
    console.log(`[ratelimit] user=${u.username} blocked per-min recent=${recent} cap=${perMin}`);
    return res.status(429).json({ error: `Rate limit: max ${perMin} numbers/minute. Try again shortly.`, code: 'rate_per_min', retry_after: 60 });
  }
  if (active + count > concurrent) {
    console.log(`[ratelimit] user=${u.username} blocked concurrent active=${active} cap=${concurrent}`);
    return res.status(429).json({ error: `Concurrent limit: max ${concurrent} active numbers. Release one to continue.`, code: 'rate_concurrent', active, cap: concurrent });
  }

  const result = { allocated: [], errors: [] };
  const insAlloc = db.prepare(`
    INSERT INTO allocations (user_id, provider, country_code, operator, phone_number, status, price_bdt, service_id, range_id, range_label, no_expire, source)
    VALUES (?, ?, ?, ?, ?, 'active', ?, ?, ?, ?, ?, ?)
  `);
  const claimFree = db.prepare(`
    UPDATE pool_numbers
    SET status = 'allocated', allocated_user_id = ?, allocated_at = strftime('%s','now'),
        updated_at = strftime('%s','now')
    WHERE id = (
      SELECT id FROM pool_numbers WHERE range_id = ? AND status = 'free' ORDER BY id LIMIT 1
    )
    RETURNING id, msisdn
  `);

  const noExpireFlag = isVip ? 1 : 0;

  const tx = db.transaction(() => {
    for (let i = 0; i < count; i++) {
      const claimed = claimFree.get(u.id, rangeRow.id);
      if (!claimed) { result.errors.push('Pool empty for this range'); break; }
      const allocRes = insAlloc.run(
        u.id, rangeRow.provider, rangeRow.country_code,
        rangeRow.operator || null, claimed.msisdn, rangeRow.price_bdt || 0,
        rangeRow.service_id || null, rangeRow.id, rangeRow.range_label || null,
        noExpireFlag, source
      );
      result.allocated.push({
        id: allocRes.lastInsertRowid,
        phone_number: claimed.msisdn,
        provider: rangeRow.provider,
        country_code: rangeRow.country_code,
        operator: rangeRow.operator,
        no_expire: !!noExpireFlag,
      });
    }
  });
  try { tx(); }
  catch (e) { return res.status(500).json({ error: e.message, ...result }); }

  res.json({ ...result, is_vip: isVip });
}

// GET /api/numbers/summary — agent stats
router.get('/summary', authRequired, (req, res) => {
  const u = req.user.id;
  const todayStart = Math.floor(new Date().setHours(0, 0, 0, 0) / 1000);
  const weekStart = todayStart - 7 * 86400;
  const monthStart = todayStart - 30 * 86400;
  const cnt = (since) => {
    const r = db.prepare(
      "SELECT COUNT(*) c, COALESCE(SUM(price_bdt),0) s FROM cdr WHERE user_id=? AND status='billed' AND created_at >= ?"
    ).get(u, since);
    return { c: r.c, s: +(+r.s).toFixed(2) };
  };
  const avgWait = (since) => {
    const r = db.prepare(`
      SELECT COALESCE(AVG(otp_received_at - allocated_at), 0) AS avg_sec,
             COALESCE(MIN(otp_received_at - allocated_at), 0) AS min_sec,
             COALESCE(MAX(otp_received_at - allocated_at), 0) AS max_sec,
             COUNT(*) AS samples
      FROM allocations
      WHERE user_id = ? AND status = 'received'
        AND otp_received_at IS NOT NULL AND allocated_at IS NOT NULL
        AND otp_received_at >= allocated_at AND otp_received_at >= ?
    `).get(u, since);
    return {
      avg_sec: Math.round(r.avg_sec || 0),
      min_sec: Math.round(r.min_sec || 0),
      max_sec: Math.round(r.max_sec || 0),
      samples: r.samples || 0,
    };
  };

  res.json({
    today: cnt(todayStart),
    week: cnt(weekStart),
    month: cnt(monthStart),
    active: db.prepare("SELECT COUNT(*) c FROM allocations WHERE user_id=? AND status='active'").get(u).c,
    wait_time: {
      today: avgWait(todayStart),
      week: avgWait(weekStart),
      month: avgWait(monthStart),
      all_time: avgWait(0),
    },
  });
});

// =============================================================
// Helper: when an OTP is confirmed, write CDR + credit agent.
// Used by provider bots (seven1telBot, etc.).
// =============================================================
async function markOtpReceived(allocation, otpCode, cli = null, smsTextArg = null, auditCtx = null) {
  // Backward-compat: older callers passed only (alloc, otp, cli) or
  // (alloc, otp, cli, smsText). New callers pass an auditCtx as 5th arg:
  //   { source: 'ims'|'xisora'|..., source_msg_id: 'dedup_key' }
  const smsText = (typeof smsTextArg === 'string') ? smsTextArg : null;
  const audit = (auditCtx && typeof auditCtx === 'object') ? auditCtx : {};
  const { logOtpAudit } = require('./otpAudit');
  const auditBase = {
    source: audit.source || 'unknown',
    source_msg_id: audit.source_msg_id || null,
    phone_number: allocation.phone_number,
    cli: cli || null,
    otp_code: otpCode,
    sms_text: smsText,
    allocation_id: allocation.id,
    user_id: allocation.user_id,
  };
  // Idempotency / re-confirm safety:
  //   • If allocation is already 'received' with the SAME otp → no-op (dedupe).
  //   • If it's 'received' with a DIFFERENT otp (site sent a 2nd code) → log it
  //     as a fresh notification but do NOT bill again. Stores latest OTP on row.
  const fresh = db.prepare(
    `SELECT id, status, otp, allocated_at, otp_received_at, no_expire FROM allocations WHERE id = ?`
  ).get(allocation.id);
  if (!fresh) {
    throw new Error('allocation_not_found');
  }
  if (fresh && fresh.status === 'received') {
    if (fresh.otp === otpCode) {
      logOtpAudit({ ...auditBase, outcome: 'duplicate',
        miss_reason: 'identical OTP already recorded for allocation' });
      return;
    }
    db.prepare(`UPDATE allocations SET otp = ?, otp_received_at = strftime('%s','now') WHERE id = ?`)
      .run(otpCode, allocation.id);
    db.prepare(`
      INSERT INTO notifications (user_id, title, message, type)
      VALUES (?, 'Additional OTP', ?, 'info')
    `).run(allocation.user_id, `${allocation.phone_number} → ${otpCode} (resend / 2nd code)`);
    logOtpAudit({ ...auditBase, outcome: 'resend',
      miss_reason: '2nd OTP after allocation already billed (no re-bill)' });
    return;
  }

  const nowSec = Math.floor(Date.now() / 1000);
  const expirySec = Math.max(1, +getOtpExpirySec() || 600);
  if (fresh.status !== 'active') {
    logOtpAudit({ ...auditBase, outcome: 'mismatch',
      miss_reason: `allocation status is ${fresh.status}; expired/released numbers cannot receive OTP` });
    throw new Error(`allocation_not_active:${fresh.status}`);
  }
  if ((+fresh.allocated_at || 0) + expirySec < nowSec) {
    // VIP no-expire allocations can receive OTP indefinitely.
    const noExpire = !!fresh.no_expire || !!(allocation && allocation.no_expire);
    if (!noExpire) {
      logOtpAudit({ ...auditBase, outcome: 'mismatch',
        miss_reason: `allocation older than expiry window (${expirySec}s); OTP rejected` });
      throw new Error('allocation_expired_by_time');
    }
  }

  const { agent_amount } = agentPayout({
    provider: allocation.provider,
    country_code: allocation.country_code,
    operator: allocation.operator,
  });

  const tx = db.transaction(() => {
    db.prepare(`
      UPDATE allocations SET otp = ?, cli = COALESCE(?, cli),
             status = 'received', otp_received_at = strftime('%s','now')
      WHERE id = ?
    `).run(otpCode, cli || null, allocation.id);

    db.prepare(`
      INSERT INTO cdr (user_id, allocation_id, provider, country_code, operator, phone_number, otp_code, cli, price_bdt, status, service_id, sms_text)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'billed', ?, ?)
    `).run(
      allocation.user_id, allocation.id, allocation.provider,
      allocation.country_code, allocation.operator, allocation.phone_number,
      otpCode, cli || null, agent_amount, allocation.service_id || null,
      smsText
    );

    if (agent_amount > 0) {
      db.prepare(`UPDATE users SET balance = balance + ?, otp_count = otp_count + 1 WHERE id = ?`)
        .run(agent_amount, allocation.user_id);
      db.prepare(`
        INSERT INTO payments (user_id, amount_bdt, type, method, reference, note)
        VALUES (?, ?, 'credit', 'auto', ?, 'OTP commission')
      `).run(allocation.user_id, agent_amount, `otp:${allocation.id}`);
    } else {
      db.prepare(`UPDATE users SET otp_count = otp_count + 1 WHERE id = ?`).run(allocation.user_id);
    }

    const label = allocation.operator || allocation.country_code || '';
    const cliTag = cli ? `${cli} ` : '';
    const prefix = label ? `[${label}] ` : '';
    const notifMsg = agent_amount > 0
      ? `${cliTag}${prefix}${allocation.phone_number} → ${otpCode} (+৳${agent_amount})`
      : `${cliTag}${prefix}${allocation.phone_number} → ${otpCode}`;
    db.prepare(`
      INSERT INTO notifications (user_id, title, message, type)
      VALUES (?, ?, ?, 'success')
    `).run(allocation.user_id, 'OTP received', notifMsg);
  });
  try {
    tx();
    logOtpAudit({ ...auditBase, outcome: 'billed', amount_bdt: agent_amount });
    // Fire-and-forget Telegram push for VIP agents who configured a bot.
    try {
      const { pushOtpToUser } = require('./telegramDelivery');
      pushOtpToUser(allocation.user_id, {
        phone_number: allocation.phone_number,
        otp: otpCode,
        cli,
        country: allocation.country_code,
        operator: allocation.operator,
        sms_text: smsText,
      });
    } catch (_) { /* never block bill on push errors */ }
  } catch (e) {
    logOtpAudit({ ...auditBase, outcome: 'error',
      miss_reason: `tx failed: ${e.message}` });
    throw e;
  }
}

module.exports = router;
module.exports.markOtpReceived = markOtpReceived;
module.exports.allocateNumbers = allocateNumbers;
